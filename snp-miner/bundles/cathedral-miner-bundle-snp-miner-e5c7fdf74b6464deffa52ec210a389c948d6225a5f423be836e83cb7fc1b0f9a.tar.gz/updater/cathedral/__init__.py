"""Cathedral miner updater, as shipped in a signed host bundle."""
